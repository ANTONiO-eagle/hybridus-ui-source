from pathlib import Path
import sys,subprocess,tempfile,json
r=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else None
scene=(r/'applications/services/desktop/scenes/desktop_scene_quick_settings.c').read_text();saved=(r/'lib/toolbox/saved_struct.c').read_text()
def fun(s,sig):
 a=s.index(sig);i=s.index('{',a)+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
code=r'''
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define furi_check assert
#define FURI_LOG_I(...) ((void)0)
#define FURI_LOG_E(...) ((void)0)
#define HYBRIDUS_MUTE_PATH "/int/.hybridus-mute"
#define HYBRIDUS_MUTE_MAGIC 0xC8
#define HYBRIDUS_MUTE_VERSION 1
#define RECORD_STORAGE "storage"
enum {FSAM_READ,FSAM_WRITE,FSOM_CREATE_ALWAYS,FSOM_OPEN_EXISTING};
typedef struct{int dummy;}Storage;
typedef struct{int pos;}File;
static uint8_t disk[64];static size_t len;
static bool exists,read_fail;static int write_budget=-1;
static int write_opens,write_calls,write_bytes,read_opens;
static void* furi_record_open(const char*s){return (void*)1;}
static void furi_record_close(const char*s){}
static File* storage_file_alloc(Storage*s){return calloc(1,sizeof(File));}
static void storage_file_free(File*f){free(f);}
static void storage_file_close(File*f){}
static const char* storage_file_get_error_desc(File*f){return "test I/O";}
static bool storage_file_open(File*f,const char*path,int access,int mode){
 assert(strcmp(path,HYBRIDUS_MUTE_PATH)==0);f->pos=0;
 if(access==FSAM_READ){read_opens++;assert(mode==FSOM_OPEN_EXISTING);return exists&&!read_fail;}
 write_opens++;assert(mode==FSOM_CREATE_ALWAYS);exists=true;len=0;return true;
}
static size_t storage_file_read(File*f,void*p,size_t n){size_t avail=len-f->pos;if(n>avail)n=avail;memcpy(p,disk+f->pos,n);f->pos+=n;return n;}
static size_t storage_file_write(File*f,const void*p,size_t n){
 write_calls++;if(write_budget>=0&&n>(size_t)write_budget)n=write_budget;
 if(write_budget>=0)write_budget-=n;
 assert(f->pos+n<=sizeof(disk));memcpy(disk+f->pos,p,n);f->pos+=n;len=f->pos;write_bytes+=n;return n;
}
'''
code+=fun(saved,'typedef struct {')+' SavedStructHeader;\n'
code+=fun(saved,'bool saved_struct_save(')+'\n'+fun(saved,'bool saved_struct_load(')+'\n'
code+=fun(scene,'static void desktop_scene_quick_settings_save_restore_volume(')+'\n'
code+=r'''
// Baseline 0.6.2 call from the MuteChanged case: immediate save on every toggle.
static void baseline(uint8_t restore){saved_struct_save(HYBRIDUS_MUTE_PATH,&restore,sizeof(restore),HYBRIDUS_MUTE_MAGIC,HYBRIDUS_MUTE_VERSION);}
static void reset(void){exists=false;len=0;read_fail=false;write_budget=-1;write_opens=write_calls=write_bytes=read_opens=0;}
static void counts(void){write_opens=write_calls=write_bytes=read_opens=0;}
static void seed(uint8_t v){baseline(v);counts();}
static void verify(uint8_t v){uint8_t got=0;assert(saved_struct_load(HYBRIDUS_MUTE_PATH,&got,1,0xC8,1));assert(got==v);}
int main(void){
 assert(sizeof(SavedStructHeader)==8);
 reset();for(int i=0;i<40;i++)baseline(12);assert(write_opens==40&&write_calls==80&&write_bytes==360);puts("baseline_missing_40 40 80 360 0");
 reset();for(int i=0;i<40;i++)desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==1&&write_calls==2&&write_bytes==9&&read_opens==40);puts("optimized_missing_40 1 2 9 40");verify(12);
 reset();seed(12);for(int i=0;i<40;i++)baseline(12);assert(write_opens==40&&write_bytes==360);puts("baseline_valid_40 40 80 360 0");
 reset();seed(12);for(int i=0;i<40;i++)desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==0&&write_calls==0&&write_bytes==0&&read_opens==40);puts("optimized_valid_40 0 0 0 40");verify(12);
 reset();seed(10);uint8_t values[]={8,8,12,12,3,3};for(int i=0;i<6;i++)baseline(values[i]);assert(write_opens==6&&write_bytes==54);puts("baseline_changed_6 6 12 54 0");
 reset();seed(10);for(int i=0;i<6;i++)desktop_scene_quick_settings_save_restore_volume(values[i]);assert(write_opens==3&&write_bytes==27&&read_opens==6);puts("optimized_changed_6 3 6 27 6");verify(3);
 reset();seed(12);disk[2]^=1;desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==1);verify(12);
 reset();seed(12);disk[0]^=1;desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==1);verify(12);
 reset();seed(12);disk[1]^=1;desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==1);verify(12);
 reset();seed(12);len=8;desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==1);verify(12);
 reset();seed(8);read_fail=true;for(int i=0;i<40;i++)desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==40&&write_bytes==360);read_fail=false;verify(12);puts("optimized_unreadable_40 40 80 360 40");
 reset();seed(8);write_budget=8;desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==1&&len==8);write_budget=-1;desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==2);verify(12);desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==2);
 reset();seed(12);baseline(3);counts();desktop_scene_quick_settings_save_restore_volume(12);assert(write_opens==1);verify(12);
 puts("PASS real production mute helper + real saved_struct_save/load with file I/O spies; missing/corrupt magic/version/checksum/truncated/read fail/partial-write recovery/external change; no RAM cache, changed value saved immediately, retry after failed write.");
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'writes.c';p.write_text(code);exe=p.with_suffix('');subprocess.run([sys.executable,'-m','ziglang','cc','-std=gnu11','-UNDEBUG',str(p),'-o',str(exe)],check=True);res=subprocess.check_output([str(exe)],text=True);print(res)
 rows={}
 for l in res.splitlines():
  parts=l.split()
  if len(parts)==5 and parts[1].isdigit():rows[parts[0]]=dict(zip(['create_always_opens','write_calls','file_payload_and_header_bytes','read_open_attempts'],map(int,parts[1:])))
 if out:out.write_text(json.dumps({'method':'Host execution of actual production C helper and actual saved_struct_save/load with memory file I/O spies. Baseline statement from 0.6.2 MuteChanged. Logical file writes, not physical SD controller writes or endurance. 40 toggles=20 mute/unmute cycles with same restore volume. Notification settings saves remain one per toggle and are NOT optimized.','cases':rows,'saved_struct_header_bytes':8,'private_mute_payload_bytes':1,'hardware_tested':False},indent=2)+'\n')
