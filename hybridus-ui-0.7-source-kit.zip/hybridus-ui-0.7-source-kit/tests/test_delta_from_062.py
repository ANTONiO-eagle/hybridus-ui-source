from pathlib import Path
import sys,subprocess,tempfile
r=Path(sys.argv[1]).resolve();o=Path(__file__).resolve().parents[1];names=(o/'baseline/changed-files-062.txt').read_text().splitlines()
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp)
 for n in names:
  s=subprocess.run(['git','show','HEAD:'+n],cwd=r,capture_output=True)
  if s.returncode==0:(d/n).parent.mkdir(parents=True,exist_ok=True);(d/n).write_bytes(s.stdout)
 subprocess.run(['git','apply',str(o/'baseline/hybridus-ui-0.6.2-095e-preserve.patch')],cwd=d,check=True)
 changed={n for n in names if (d/n).read_bytes()!=(r/n).read_bytes()}
 expected={'assets/icons/MainMenu/HybridusScripts_14/frame_0'+str(i)+'.png' for i in [1,2]};expected.update(['applications/services/desktop/views/desktop_view_quick_settings.c','applications/services/desktop/scenes/desktop_scene_quick_settings.c','applications/system/updater/util/hybridus_preserve.h']);assert changed==expected,changed
 n='applications/services/desktop/views/desktop_view_quick_settings.c';assert (d/n).read_text().replace('const int x = 15 + 19 * i;','const int x = 15 + 20 * i;').replace('x - 1, y - 1, w + 2, h + 2','x - 1, y - 1, w + 1, h + 2')==(r/n).read_text()
 n='applications/services/desktop/scenes/desktop_scene_quick_settings.c';s=(r/n).read_text();start=s.index('// This file belongs only');end=s.index('static void desktop_scene_quick_settings_callback(',start);s=s[:start]+s[end:];s=s.replace('            desktop_scene_quick_settings_save_restore_volume(restore);','''            saved_struct_save(HYBRIDUS_MUTE_PATH, &restore, sizeof(restore),
                              HYBRIDUS_MUTE_MAGIC, HYBRIDUS_MUTE_VERSION);''');assert s==(d/n).read_text()
 n='applications/system/updater/util/hybridus_preserve.h';assert (d/n).read_text().replace('hybridus-ui-0.6.2-','hybridus-ui-0.7-')==(r/n).read_text()
 print('PASS exact delta vs 0.6.2: 2 Scripts PNGs, slider column pitch +1 / focus extent -1, private mute dedup helper/call, preserve tag only. Entire input/navigation, slider values, BT/Dummy/other button cells, notification saves, settings backend/format, Color, menu, Bluetooth/Games/Media icons, applications/radio/API unchanged.')
 print('\n'.join(sorted(changed)))
