from pathlib import Path
import sys,subprocess
from PIL import Image,ImageDraw
r=Path(sys.argv[1]).resolve();o=Path(sys.argv[2]).resolve();o.mkdir(parents=True,exist_ok=True)
def fun(s,sig):
 a=s.index(sig);i=s.index('{',a)+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
cards=[('Apps','MainMenu/Plugins_14/frame_01.png'),('Bluetooth','MainMenu/HybridusBluetooth_14/frame_01.png'),('Games','MainMenu/HybridusGames_14/frame_01.png'),('GPIO','MainMenu/GPIO_14/frame_01.png'),('iButton','MainMenu/iButton_14/frame_01.png'),('Infrared','MainMenu/Infrared_14/frame_01.png'),('Media','MainMenu/HybridusMedia_14/frame_01.png'),('NFC','MainMenu/NFC_14/frame_01.png'),('RFID','MainMenu/125khz_14/frame_01.png'),('Scripts','MainMenu/HybridusScripts_14/frame_01.png'),('Sub-GHz','MainMenu/Sub1ghz_14/frame_01.png'),('Tools','MainMenu/Clock_14/frame_01.png'),('USB','MainMenu/BadUsb_14/frame_01.png'),('Settings','MainMenu/Settings_14/frame_01.png')]
font=(r/'lib/u8g2/u8g2_fonts.c').read_text(encoding='latin1')
code='''#include "u8g2.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <assert.h>
#define furi_check assert
#define COUNT_OF(a) (sizeof(a)/sizeof(a[0]))
enum{FontPrimary,FontSecondary,FontBatteryPercent,ColorWhite=0,ColorBlack=1,AlignCenter=4,AlignBottom=5};
typedef struct{u8g2_t fb;uint8_t data[1024];}Canvas;
typedef struct{int w,h;const uint8_t*data;}IconAnimation;
typedef struct{const char*label;IconAnimation*icon;}MenuItem;
typedef struct{MenuItem*items;size_t count,position,scroll_counter;}MenuModel;
'''
for name in ['u8g2_font_helvB08_tr','u8g2_font_haxrcorp4089_tr','u8g2_font_5x7_tr']:
 a=font.index('const uint8_t '+name+'[');b=font.index(';\n',a)+1;code+=font[a:b]+'\n'
code+='''
static void canvas_set_color(Canvas*c,int a){u8g2_SetDrawColor(&c->fb,a);}
static void canvas_set_font(Canvas*c,int a){u8g2_SetFontMode(&c->fb,1);u8g2_SetFont(&c->fb,a==FontPrimary?u8g2_font_helvB08_tr:(a==FontBatteryPercent?u8g2_font_5x7_tr:u8g2_font_haxrcorp4089_tr));}
static void canvas_draw_box(Canvas*c,int x,int y,int w,int h){u8g2_DrawBox(&c->fb,x,y,w,h);}
static void canvas_draw_rframe(Canvas*c,int x,int y,int w,int h,int rad){u8g2_DrawRFrame(&c->fb,x,y,w,h,rad);}
static void canvas_draw_line(Canvas*c,int x,int y,int a,int b){u8g2_DrawLine(&c->fb,x,y,a,b);}
static void canvas_draw_dot(Canvas*c,int x,int y){u8g2_DrawPixel(&c->fb,x,y);}
static void canvas_draw_str_aligned(Canvas*c,int x,int y,int h,int v,const char*s){if(h==AlignCenter)x-=u8g2_GetUTF8Width(&c->fb,s)/2;if(v==AlignCenter)y+=u8g2_GetAscent(&c->fb)/2;u8g2_DrawUTF8(&c->fb,x,y,s);}
static int icon_animation_get_width(IconAnimation*i){return i->w;}
static int icon_animation_get_height(IconAnimation*i){return i->h;}
static void canvas_draw_icon_animation(Canvas*c,int x,int y,IconAnimation*i){u8g2_DrawXBM(&c->fb,x,y,i->w,i->h,i->data);}
static void elements_scrollable_text_line_str(Canvas*c,int x,int y,int w,const char*s,size_t scroll,bool ellipsis,bool centered){assert(u8g2_GetUTF8Width(&c->fb,s)<=w);canvas_draw_str_aligned(c,x,y,AlignCenter,AlignBottom,s);}
'''
e=(r/'applications/services/gui/elements.c').read_text();helpers=(r/'applications/system/menu_styles/menu_style_helpers.h').read_text();style=(r/'applications/system/menu_styles/dsi.c').read_text()
for sig in ['void elements_bold_rounded_frame(','void elements_slightly_rounded_frame(']:code+=fun(e,sig)+'\n'
for sig in ['static inline const char* menu_style_label(','static inline size_t menu_style_scroll(','static inline void menu_style_icon_centered(','static inline void menu_style_scrollbar_horizontal(']:code+=fun(helpers,sig)+'\n'
code+=fun(style,'static void menu_style_dsi_draw(')+'\n'
for i,(label,path) in enumerate(cards):
 im=Image.open(r/'assets/icons'/path).convert('1');w,h=im.size;data=[]
 for y in range(h):
  for bx in range((w+7)//8):data.append(sum((1<<b) for b in range(8) if bx*8+b<w and im.getpixel((bx*8+b,y))==0))
 code+=f'static const uint8_t data_{i}[]={{'+','.join(map(str,data))+'};\n'+f'static IconAnimation icon_{i}={{ {w},{h},data_{i} }};\n'
code+='static MenuItem items[]={'+','.join('{"'+l+'",&icon_'+str(i)+'}' for i,(l,_) in enumerate(cards))+'};\n'
code+='''int main(){static const u8x8_display_info_t info={.tile_width=16,.tile_height=8,.pixel_width=128,.pixel_height=64};
for(int i=0;i<14;i++){Canvas c={0};c.fb.u8x8.display_info=&info;u8g2_SetupBuffer(&c.fb,c.data,8,u8g2_ll_hvline_vertical_top_lsb,U8G2_R0);MenuModel m={.items=items,.count=14,.position=i};menu_style_dsi_draw(&c,&m);char path[700];snprintf(path,sizeof(path),"OUT/frame-%02d.pbm",i);FILE*f=fopen(path,"wb");fprintf(f,"P1\\n128 64\\n");for(int y=0;y<64;y++){for(int x=0;x<128;x++)fprintf(f,"%d ",(c.data[x+(y/8)*128]>>(y%8))&1);fprintf(f,"\\n");}fclose(f);}puts("PASS production DSi drawing, actual fonts and first-frame stock icon assets: all 14 cards, labels fit. Host preview only.");}'''.replace('OUT',str(o))
(o/'render.c').write_text(code)
files=[str(p) for p in (r/'lib/u8g2').glob('*.c') if p.name not in ['u8g2_fonts.c','u8g2_glue.c']]
subprocess.run([sys.executable,'-m','ziglang','cc','-std=gnu11','-Os','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I'+str(r/'lib/u8g2'),str(o/'render.c'),*files,'-o',str(o/'render')],check=True)
subprocess.run([str(o/'render')],check=True)
im=Image.new('RGB',(768,8*218+45),'#eeeeee');d=ImageDraw.Draw(im);d.text((10,8),'Hybridus UI 0.7 - HOST PREVIEW / NOT DEVICE',fill='black')
for i,(label,_) in enumerate(cards):
 screen=Image.open(o/f'frame-{i:02d}.pbm').convert('RGB').resize((384,192),Image.Resampling.NEAREST)
 x=(i%2)*384;y=(i//2)*218+45;d.text((x+5,y),label,fill='black');im.paste(screen,(x,y+15))
im=im.crop((0,0,768,7*218+45));im.save(o/'menu-07-preview.png')
