#!/usr/bin/env python3
"""Host tests execute the production C bodies against non-device stubs. Never flash."""
from pathlib import Path
import subprocess, tempfile, sys, shutil, importlib.util
root=Path(sys.argv[1] if len(sys.argv)>1 else 'source').resolve()
view=root/'applications/services/desktop/views/desktop_view_quick_settings.c'
header=view.with_suffix('.h')
def strip_includes(s):return '\n'.join(l for l in s.splitlines() if not l.startswith('#include') and l!='#pragma once')
stubs=r'''
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <stdatomic.h>
#define furi_assert assert
#define CLAMP(v,hi,lo) ((v)>(hi)?(hi):((v)<(lo)?(lo):(v)))
typedef enum {InputKeyUp,InputKeyDown,InputKeyLeft,InputKeyRight,InputKeyOk,InputKeyBack} InputKey;
typedef enum {InputTypePress,InputTypeRelease,InputTypeShort,InputTypeLong,InputTypeRepeat} InputType;
typedef struct {InputKey key; InputType type;} InputEvent;
typedef struct {void* model;} View;
typedef struct {} Canvas;
typedef struct {int w,h;} Icon;
static Icon I_Pin_star_7x7={7,7}, I_Volup_8x6={8,6}, I_ButtonLeftSmall_3x5={3,5}, I_ButtonRightSmall_3x5={3,5}, I_DoorLeft_70x55={70,55}, I_DoorRight_70x55={70,55};
#define STATUS_BAR_Y_SHIFT 13
enum {ViewModelTypeLocking,ColorBlack,ColorXOR,ColorWhite,FontSecondary,AlignCenter};
#define with_view_model(v,decl,code,update) do {decl=(v)->model; code;} while(0)
static View* view_alloc(void){return calloc(1,sizeof(View));}
static void view_allocate_model(View*v,int t,size_t n){v->model=calloc(1,n);}
#define view_set_context(...) ((void)0)
#define view_set_draw_callback(...) ((void)0)
#define view_set_input_callback(...) ((void)0)
static void view_free(View*v){free(v->model);free(v);}
static void canvas_set_color(Canvas*c,int x){}
static void canvas_set_font(Canvas*c,int x){}
static void canvas_draw_str(Canvas*c,int x,int y,const char*s){assert(x>=0&&y>=0&&x<128&&y<64);}
static void check_rect(int x,int y,size_t w,size_t h){assert(x>=0&&y>=0&&x+(int)w<=128&&y+(int)h<=64);}
static void elements_frame(Canvas*c,int x,int y,size_t w,size_t h){check_rect(x,y,w,h);}
static void elements_bold_rounded_frame(Canvas*c,int x,int y,size_t w,size_t h){check_rect(x,y,w,h);}
static void canvas_draw_rframe(Canvas*c,int x,int y,size_t w,size_t h,int r){check_rect(x,y,w,h);}
static void canvas_draw_rbox(Canvas*c,int x,int y,size_t w,size_t h,int r){check_rect(x,y,w,h);}
static void canvas_draw_str_aligned(Canvas*c,int x,int y,int h,int v,const char*s){assert(x>=0&&x<128&&y>=0&&y<64);}
static void canvas_draw_box(Canvas*c,int x,int y,size_t w,size_t h){check_rect(x,y,w,h);}
static int icon_get_width(const Icon*i){return i->w;}
static int icon_get_height(const Icon*i){return i->h;}
static void canvas_draw_icon(Canvas*c,int x,int y,const Icon*i){
 if(i==&I_DoorLeft_70x55||i==&I_DoorRight_70x55){assert(y==13);assert(x==-57||x==116);return;}
 check_rect(x,y,i->w,i->h);
}
'''
tests=r'''
static int event_count; static DesktopEvent last;
static void cb(DesktopEvent ev,void*ctx){event_count++;last=ev;}
static bool key(DesktopQuickSettingsView*v,InputKey k,InputType t){InputEvent e={k,t};return desktop_quick_settings_input_callback(&e,v);}
int main(void){
 DesktopQuickSettingsView*v=desktop_quick_settings_alloc();desktop_quick_settings_set_callback(v,cb,NULL);
 desktop_quick_settings_reset(v,0.65f,0.4f,true,false);
 desktop_quick_settings_set_system_state(v,true,false,13);
 DesktopQuickSettingsViewModel*m=v->view->model;
 assert(m->idx==0&&m->brightness==13&&m->volume==8&&m->bluetooth);
 for(int i=0;i<100;i++)key(v,InputKeyUp,InputTypeRepeat);
 assert(m->brightness==20&&last==DesktopQuickSettingsEventBrightnessChanged);
 for(int i=0;i<100;i++)key(v,InputKeyDown,InputTypeRepeat);
 assert(m->brightness==0);
 key(v,InputKeyRight,InputTypeShort);assert(m->idx==1&&last==DesktopQuickSettingsEventSave);
 key(v,InputKeyUp,InputTypeShort);assert(m->volume==9&&last==DesktopQuickSettingsEventVolumeChanged);
 key(v,InputKeyRight,InputTypeShort);assert(m->idx==2);
 key(v,InputKeyOk,InputTypeShort);assert(!m->bluetooth&&last==DesktopQuickSettingsEventBluetoothChanged);
 key(v,InputKeyOk,InputTypeRepeat);assert(!m->bluetooth); // no repeated toggling
 key(v,InputKeyUp,InputTypeShort);assert(m->idx==2); // no opposite-direction wrapping
 key(v,InputKeyRight,InputTypeShort);assert(m->idx==3);
 key(v,InputKeyOk,InputTypeShort);assert(m->dummy&&last==DesktopQuickSettingsEventDummyChanged);
 key(v,InputKeyDown,InputTypeShort);assert(m->idx==5);
 key(v,InputKeyOk,InputTypeShort);assert(m->volume==0&&m->restore_volume==9&&last==DesktopQuickSettingsEventMuteChanged);
 key(v,InputKeyOk,InputTypeShort);assert(m->volume==9);
 key(v,InputKeyLeft,InputTypeShort);assert(m->idx==4);
 key(v,InputKeyOk,InputTypeShort);assert(!m->vibro&&last==DesktopQuickSettingsEventVibroChanged);
 key(v,InputKeyDown,InputTypeShort);assert(m->idx==6);
 key(v,InputKeyDown,InputTypeShort);assert(m->idx==6);
 key(v,InputKeyOk,InputTypeShort);assert(m->left_hand&&last==DesktopQuickSettingsEventHandChanged);
 key(v,InputKeyUp,InputTypeShort);assert(m->idx==4);
 key(v,InputKeyRight,InputTypeShort);assert(m->idx==5);
 key(v,InputKeyDown,InputTypeShort);assert(m->idx==6);
 key(v,InputKeyUp,InputTypeShort);assert(m->idx==5); // preserve column over spanning hand cell
 key(v,InputKeyLeft,InputTypeShort);assert(m->idx==4);
 key(v,InputKeyLeft,InputTypeShort);assert(m->idx==1);
 key(v,InputKeyRight,InputTypeShort);assert(m->idx==4); // return to prior row, not a different page
 assert(!key(v,InputKeyBack,InputTypeShort));
 assert(key(v,InputKeyBack,InputTypeLong));assert(last==DesktopQuickSettingsEventClose);
 desktop_quick_settings_reset(v,-1.0f,2.0f,false,true);
 assert(desktop_quick_settings_get_brightness(v)==0&&desktop_quick_settings_get_volume(v)==1);
 desktop_quick_settings_set_system_state(v,false,false,0);assert(m->restore_volume==1);
 desktop_quick_settings_set_system_state(v,false,false,255);assert(m->restore_volume==20);
 Canvas c;int draws=0;
 for(int i=0;i<7;i++)for(int n=0;n<=20;n++)for(int flags=0;flags<16;flags++){
  m->idx=i;m->brightness=n;m->volume=20-n;m->bluetooth=flags&1;m->dummy=flags&2;m->vibro=flags&4;m->left_hand=flags&8;
  desktop_quick_settings_draw_callback(&c,m);draws++;
 }
 // Walk every directional transition for bounds (slider and button focus).
 for(int i=0;i<7;i++)for(int k=0;k<4;k++){
  m->idx=i;key(v,(InputKey)k,InputTypeShort);assert(m->idx<7);
 }
 assert(draws==2352);
 desktop_quick_settings_free(v);puts("PASS inherited UI: spatial arrows without wrap, direct vertical sliders, no edit mode, 5 OK-only toggles, Mute restore, column retention, Back; 2352 draw-bound cases");
 return 0;
}
'''
color_stubs=r'''
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <assert.h>
#include <stdio.h>
#include <stdatomic.h>
#define INT_PATH(x) x
static bool load_ok=false,save_ok=true;static uint8_t stored;
static bool saved_struct_load(const char*p,void*d,size_t n,uint8_t m,uint8_t v){if(load_ok)*(uint8_t*)d=stored;return load_ok;}
static bool saved_struct_save(const char*p,const void*d,size_t n,uint8_t m,uint8_t v){if(save_ok)stored=*(uint8_t*)d;return save_ok;}
'''
color_tests=r'''
int main(void){
 hybridus_color_load();assert(hybridus_color_get()==0);
 for(int i=0;i<=3;i++){assert(hybridus_color_set(i));assert(hybridus_color_get()==i);}
 assert(!hybridus_color_set(4)&&hybridus_color_get()==3);
 assert(!hybridus_color_set(255)&&hybridus_color_get()==3);
 save_ok=false;assert(!hybridus_color_set(1)&&hybridus_color_get()==3);
 load_ok=true;stored=255;hybridus_color_load();assert(hybridus_color_get()==0);
 stored=2;hybridus_color_load();assert(hybridus_color_get()==2);
 puts("PASS COLOR: missing/corrupt fallback, 4 valid values, invalid rejected, failed-save rollback, reload");
}
'''
# Execute the actual HAL getter too; separately verify both RPC paths delegate to it.
hal=(root/'targets/f7/furi_hal/furi_hal_version.c').read_text()
a=hal.index('FuriHalVersionColor furi_hal_version_get_hw_color(void)');b=hal.index('\n}',a)+2
color_stubs+='\ntypedef int FuriHalVersionColor;\nstatic struct {int board_color;} furi_hal_version={2};\n'
color_tests=hal[a:b]+'\n'+color_tests.replace('hybridus_color_load();assert(hybridus_color_get()==0);',
    'hybridus_color_load();assert(hybridus_color_get()==0);assert(furi_hal_version_get_hw_color()==2);').replace(
    'assert(hybridus_color_get()==i);','assert(hybridus_color_get()==i);assert(furi_hal_version_get_hw_color()==(i?i:2));')
assert "furi_hal_info_get(rpc_system_system_device_info_callback, '_'" in (root/'applications/services/rpc/rpc_system.c').read_text()
assert "furi_hal_info_get(rpc_system_property_get_callback, '.'" in (root/'applications/services/rpc/rpc_property.c').read_text()
assert '"hardware", "color", furi_hal_version_get_hw_color()' in (root/'targets/f7/furi_hal/furi_hal_info.c').read_text()
assert 'config->adv_service.Service_UUID_16 |= furi_hal_version_get_hw_color();' in (root/'targets/f7/ble_glue/profiles/serial_profile.c').read_text()
print('PASS color paths: real HAL getter exercised; both device info/RPC property and BLE advertisement delegate to this getter (static); Android rendering not tested.',flush=True)
with tempfile.TemporaryDirectory() as t:
 for name,body in [('ui',stubs+strip_includes(view.with_name('desktop_events.h').read_text())+strip_includes(header.read_text())+strip_includes(view.read_text())+tests),('color',color_stubs+strip_includes((root/'lib/toolbox/hybridus_color.c').read_text())+color_tests)]:
  p=Path(t)/f'{name}.c';p.write_text(body);o=p.with_suffix('')
  compiler = ['cc'] if shutil.which('cc') else [sys.executable,'-m','ziglang','cc']
  subprocess.run(compiler+['-std=gnu11','-Wall','-Wno-unused-function','-Wno-unused-variable',str(p),'-lm','-o',str(o)],check=True)
  subprocess.run([str(o)],check=True)
print('Host stubs do NOT validate LCD appearance, RGB hardware, BLE/client cache or physical storage integrity.')
