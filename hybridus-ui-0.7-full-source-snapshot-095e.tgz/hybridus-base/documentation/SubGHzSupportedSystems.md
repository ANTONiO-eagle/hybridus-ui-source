# Sub-GHz Supported Protocols

This file lists all supported Sub-GHz protocols available in Unleashed Firmware, both tested and untested.

That list is only for default SubGHz app, apps like *Weather Station* have their own protocols list


## Static & Dynamic protocols list

*433 MHz usually means `433.92MHz` and 868 MHz = `868.35MHz`*

*If you see no frequency after protocol name, that means we don't know it, let us know in issues tab!*

*`AM650`, `FM`, `FSK476` - means modulation to use when reading the remote* 

*`FM` means you should try any existing FM modulations, `FSK???` means `FM???` in SubGHz - Read - Config*

### Garage Door Openers & Gate Openers (Boom barriers, roller shutters, etc.)
- Alutech AT-4N `433.92MHz` `AM650` (72 bits, Dynamic)
- AN-Motors (Alutech) AT4 `433.92MHz` `AM650` (64 bits, Pseudo-Dynamic, KeeLoq based)
- Ansonic `433MHz` `FM` (12 bits, Static)
- BETT `433.92MHz` `AM650` (18 bits, Static)
- Beninca ARC (TOGO2VA) `433.92MHz` `AM650` (128 bits, Dynamic AES128) (button code `0` emulates `hidden button` option on the remote)
- BFT Mitto `433.92MHz` `AM650` (64 bits, Dynamic, KeeLoq based with Seed) - (newer remotes make the Seed from the serial and decode on the fly in a normal Read; older models have a unique Seed that is required to decode, get it from a remote in programming mode or with the `Seed Capturer` app + qUnleashed; button code `0xF` is programming mode, it sends the Seed in the clear) - Add Manually: **BFT Mitto 433MHz**
- Erreka - `433.92MHz, 868.35MHz` `AM650` (KeeLoq, 64 bits) (8bit serial part in Hop - secure learning with Seed) - (IRIS IR02/IR04 on 433.92MHz, IRIS IR02/868 and IR04/868 on 868.35MHz; Seed is required to decode, get it with the `Seed Capturer` app or from a remote in programming mode; button code `0xF` is programming mode, it sends the Seed in the clear) - Add Manually: **Erreka 433MHz**, **Erreka 868MHz**
- CAME Atomo `433.92MHz, 868MHz` `AM650` (62 bits, Dynamic) (TOPD4REN, TOP44RBN, TOP42R, TOP44R)
- CAME TWEE `433.92MHz` `AM650` (54 bits, Pseudo-Dynamic) (+ TOP44FGN) (aka New Fixed Code)
- CAME `433.92MHz, 868MHz` `AM650` (12, 24 bits, Static)
- Proteco MOVER `433.92MHz` `AM650` (24 bits, Static) (TX3) - Add Manually: **Proteco 433MHz**
- Ditec GOL4 `433.92MHz` `AM650` (54 bits, Dynamic) (should be compatible with BIXLG4, BIXLS2, BIXLP2) - (right arrow emulates button `0` (hidden button))
- Prastel `433.92MHz, 868MHz` `AM650` (25 bits, Static)
- Prastel `433.92MHz, 868MHz` `AM650` (42 bits, Dynamic) - (CAME line coding; the 42 bit frame is a scrambled serial + counter, not a fixed code) (4 buttons, custom button map unverified)
- Airforce `433.92MHz, 868MHz` `AM650` (18 bits, Static)
- Chamberlain Code `AM650` (10 bits, Static)
- Clemsa `AM650` (18 bits, Static)
- Dickert MAHS `AM650` (36 bits, Static)
- Doitrand `AM650` (37 bits, Dynamic)
- Elplast/P-11B/3BK/E.C.A `433MHz` `AM650` (18 bits, Static)
- FAAC SLH `433.92MHz, 868.35MHz` `AM650` (64 bits, Dynamic) - Add Manually: **FAAC SLH 868MHz**, **FAAC SLH 433MHz**
- FAAC TM `433.92MHz, 868MHz` `AM650` (12 bits, Static) (TM 433/868 DS dip switch remotes) - `Te` is kept from the capture and replayed. CAME 12bit shares the pulse grammar and used to decode these as well, it now tells them apart by the 47 Te gap between its repeats. Add Manually: **FAAC TM 433MHz**, **FAAC TM 868MHz**
- Genius `433.92MHz, 868.35MHz` `AM650` (64 bits, Dynamic) (Genius KILO TX2/4 JLC, Amigo, other Genius models) - same frame as FAAC SLH with its own manufacture key, selected by a `Manufacture: Genius` line in the .sub file. Add Manually: **Genius 433MHz**, **Genius 868MHz**
- Gate TX `433.92MHz` `AM650` (64 bits, Static)
- Hormann `868MHz` `AM650` (44 bits, Static)
- HCS101 `AM650` (64 bits, Simple Dynamic, KeeLoq-like)
- iDO `433MHz` `AM650` (48 bits, Dynamic) (Decode only)
- KingGates Stylo 4k `433.92MHz` `AM650` (89 bits, Dynamic, KeeLoq based)
- Mastercode `AM650` (36 bits, Static)
- Megacode `AM650` (24 bits, Static)
- Nord ICE `433.92MHz` `AM650` (33 bits, Static)
- Telcoma/Cardin EDGE `433.92MHz` `AM650` (32 bits, Static, fixed code) - (EDGE2/EDGE4/EDGE20 family; 0xFF preamble + serial + one-hot channel select, gate = Ch 0)
- Nero Sketch `AM650` (40 bits, Static)
- Nice Flo `433.92MHz` `AM650` (12, 24 bits, Static)
- Nice FloR-S `433.92MHz` `AM650` (52 bits, Dynamic)
- Nice O-Code `433.92MHz` `AM650` (52, 72, 112 bits, Dynamic) - (Nice FloR-S keyed by a 16 bit installer code; use `Nice O-Code` app, it recovers the key from 4+ captures. see [SubGHzRemoteProg.md](/documentation/SubGHzRemoteProg.md#nice-o-code) for the certificate, enrolment paths and receiver LED codes)
- Nice One `433.92MHz` `AM650` (72 bits, Dynamic)
- Revers RB2 (Реверс РБ-2 (М)) `433.92MHz` `AM650` (64 bits, Static)
- Roger `433.92MHz` `AM650` (28 bits, Static)
- V2 Phoenix (Phox) `433.92MHz` `AM650` (52 bits, Dynamic) (receivers have option to enable Static mode, making them ignore rolling part of the key)
- Marantec `433.92MHz, 868MHz` `AM650` (49 bits, Static)
- Marantec24 `868MHz` `AM650` (24 bits, Static)
- Somfy Keytis `433.42MHz, 868MHz` `AM650` (80 bits, Dynamic) (KeyGo 4 RTS 4 / Keytis NS 2RTS)
- ZKTeco `430.5MHz` `AM650` (24 bits, Static - Princeton based) - (Button codes (already mapped to arrow keys): `0x30 (UP)`, `0x03 (STOP)`, `0x0C (DOWN)`) 
- Linear `300MHz` `AM650` (10 bits, Static)
- Linear Delta3 `AM650` (8 bits, Static)
- Nero Radio `434.42MHz` `AM650` (56 bits, Static mode only, Dynamic is unsupported)
- Security+1.0 `315MHz, 433.92MHz, 390MHz` `AM650` (42 bits, Dynamic)
- Security+2.0 `310MHz, 315MHz, 390MHz, 868MHz` `AM650` (62 bits, Dynamic)
- Security+2.0 Keypad `315MHz, 390MHz, 868MHz` `AM650` (86 bits, Dynamic) - (wireless keypad frame; edit or try other Pins with `Security+ PIN` app)
- Allstar Firefly 318ALD31K `318MHz` `AM650` (18 bits, Static)
- Superrollo GW60 `433.92MHz` `AM650` (KeeLoq HCS361) (67 bits, Dynamic, with CRC) (Button codes: `0x3(0xA) Up / 0x5(0xC) Down / 0x7(0xE) Stop`)

### Sensors & Smart home
- Intertechno V3 `AM650` (32 bits, Static) - Lights, sockets, other.
- Dooya `AM650` (40 bits, Static) - Electric blinds
- Power Smart `AM650` (64 bits, Static) - Blinds, shutters
- Legrand `AM650` (18 bits, Static) - Doorbells
- Somfy Telis `433.42MHz` `AM650` (56 bits, Dynamic) - (Somfy RTS; `Add Manually` entry is named `433MHz` but creates 433.42MHz)
- Feron `433.92MHz` `AM650` (32 bits, Static) - RGB LED remotes, other.
- Honeywell `AM650` (64 bits, Static) - Alarm, Sensor
- Honeywell WDB `AM650` (48 bits, Static) - Doorbell
- Magellan `433.92MHz` `AM650` (32 bits, Static) - Sensor, alarm
- Jarolift `433.92MHz` `AM650` (72 bits, Dynamic, KeeLoq based) - Automatic roller shutters

### Alarms
- Hollarm `433.92MHz` `AM650` (42 bits, Static) - Bike alarms
- GangQi `433.92MHz` `AM650` (34 bits, Static) - Bike alarms


### Generic any branded remotes
- Holtek `AM650` (40 bits, Static)
- Holtek HT12X `AM650` (12 bits, Static)
- Princeton (PT2262, PT****) `315MHz, 433.92MHz, Any other frequency` `AM650` (24 bits, Static)
- SMC5326 `315MHz, 433.92MHz, Any other frequency` `AM650` (25 bits, Static)
- Hay21 `433.92MHz` `AM650` (21 bits, Dynamic)
- Treadmill37 (QH-433) `433.92MHz` `AM650` (37 bits, Static)
- KeyFinder `433.92MHz` `AM650` (24 bits, Static)
- KeyFinder2 `433.92MHz` `AM650` (11 bits, Static) (second fob variant, frame is btn(3) + 10011 + btn(3), the button code sent twice and no serial, frames run back to back with no gap; button colour is shown but comes from one fob only)
- Doorbell32 `433.92MHz` `AM650` (32 bits, Static) (unbranded doorbells; Princeton style 1:3 PWM but 32 bits and a 14*Te guard)

---

## KeeLoq Rolling Code Supported Manufacturers list

KeeLoq is a rolling code encryption system used by many garage door openers and gate systems. 
The following manufacturers have KeeLoq support in Unleashed firmware:

*Default value for encryption type "learning" is `simple` and `10bits` for serial part in Hop*

*In case if remote uses other serial bits or different encryption type and it was verified - it will be stated in the end*

### Garage Door Openers & Gate Openers (Boom barriers, roller shutters, etc.)
- Allmatic - `868MHz` `AM650` (KeeLoq, 64 bits) (no serial part in Hop - magic XOR)
- Aprimatic - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial number art in Hop + 2bit "parity" in front of it replacing first 2 bits of serial)
- Beninca - `433.92MHz, 868MHz` `AM650` (KeeLoq, 64 bits) (no serial part in Hop - magic XOR)
- CAME Space - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - simple learning)
- Cardin S449 - `433.92MHz` `FSK12K` (KeeLoq, 64 bits) (12bit (original remotes) or 10bit (chinese remotes) serial part in Hop - normal learning) (receiver checks for 10bit only (unverified))
- Centurion - `433.92MHz` `AM650` (KeeLoq, 64 bits) (no serial in Hop, uses fixed value 0x1CE - normal learning)
- Comunello - `433.92MHz, 868MHz` `AM650` (KeeLoq, 64 bits) (normal learning)
- DEA Mio - `433.92MHz` `AM650` (KeeLoq, 64 bits) (modified serial in Hop, uses last 3 digits modifying first one (example - 419 -> C19) - simple learning)
- DoorHan - 315MHz, `433.92MHz` `AM650` (KeeLoq, 64 bits)
- DTM Neo - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - simple learning)
- Elmes Poland - `303, 433.92MHz` `AM650` (KeeLoq, 64 bits) (normal learning)
- FAAC RC,XT - `433.92MHz, 868MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning)
- Genius Bravo - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning) (Genius ECHO, Genius Bravo (Button code 0xB for prog. mode))
- Gibidi - `433.92MHz` `AM650` (KeeLoq, 64 bits)
- GSN - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning)
- HomeGate - `433.92MHz` `AM650` (KeeLoq, 64 bits)
- Hormann EcoStar - `433.92MHz` `AM650` (KeeLoq, 64 bits) (normal learning)
- IronLogic IL-100 - `433.92MHz` `AM650` (KeeLoq, 64 bits)
- IronLogic IL-100 Smart PPult - `433.92MHz` `AM650` (KeeLoq, 64 bits)
- JCM Tech - `433.92MHz` `AM650` (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- Jolly Motors - `433.92MHz` `AM650` (KeeLoq, 64 bits)
- KEY - `433.92MHz` `AM650` (KeeLoq, 64 bits) (no serial in Hop, uses fixed value 0x2FF - simple learning)
- Monarch - `433.92MHz` `AM650` (KeeLoq, 64 bits) (no serial in Hop, uses fixed value 0x100 or 0x280 - normal learning) (Dorcas 22366CLN / D-22366CLN uses 0x280)
- Phantom / Hiland - `433.92MHz` `AM650` (KeeLoq, 64 bits) (HCS300, 10bit serial part in Hop - normal learning) (the 12bit discriminator is kept in `Seed`: its low 10 bits are `serial & 0x3FF`, the top 2 differ per remote and the receiver ignores them)
- Motorline - `433.92MHz` `AM650` (KeeLoq, 64 bits) (normal learning)
- Clemsa Mutancode (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning)
- Mhouse - `433.92MHz` `AM650` (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- Nice Smilo - `433.92MHz` `AM650` (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- Normstahl - `433.92MHz` `AM650` (KeeLoq, 64 bits)
- Novoferm - `433.92MHz` `AM650` (KeeLoq, 64 bits)
- Sommer `434.42MHz, 868.80MHz` `FSK12K (or FSK476)` (KeeLoq, 64 bits) (normal learning) (TX03-868-4, Pearl, and maybe other models are supported (SOMloq))
- Steelmate - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning)
- Stilmatic (R-Tech) - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning) (receiver checks for 10bit only (unverified))
- Pujol - `433.92MHz` `AM650` (KeeLoq, 64 bits) (8bit serial part in Hop - special learning) (Pujol Vario 4, other models)
- Pujol Vario - `433.92MHz` `AM650` (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning) (older models)
- Wisniowski  - `433.92MHz` `AM650` (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning)
- Wisniowski 2 (KeeLoq, 64 bits) (normal learning)
- Wisniowski 1 ByteReversed (KeeLoq, 64 bits) (normal learning)
- Doormatic (KeeLoq, 64 bits) (normal learning)
- Elvox (KeeLoq, 64 bits) (normal learning)
- ET Blue (KeeLoq, 64 bits) (10bit serial part in Hop - normal learning)
- ET Blue Mix (KeeLoq, 64 bits) (10bit serial part in Hop - normal learning)
- ATA PTX4 (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning)
- Verex (KeeLoq, 64 bits) (normal learning)
- Mc Garcia (KeeLoq, 64 bits) (10bit serial part in Hop - simple learning)
- Fadini (KeeLoq, 64 bits) (12bit serial part in Hop - simple learning)
- Seav (KeeLoq, 64 bits) (12bit serial part in Hop - normal learning)
- JCM Tech Gen2 (KeeLoq, 64 bits) (special learning) (one input byte is not carried in the packet, so decoding brute forces it and reports it as `Seed`)
- Stagnoli (KeeLoq, 64 bits) (special learning)
- Telcoma (KeeLoq, 64 bits) (table driven learning)
- SEA (KeeLoq, 64 bits) (simple learning)
- AERF Otros (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- AERF Collbaix (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- AERF Hy dom (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- AERF Medva (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- AERF VDS (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- AERF Temp (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- AERF Sabutom (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- AERF Motorgate (KeeLoq, 64 bits) (10bit serial part in Hop - special learning)
- JCM1G EMFA (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G DMIL (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Antonio Meca (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Hy dom (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Baleato (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Cas (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Cubells (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Cyacsa (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Forsa (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Gandara (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Pujol (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Gibidi (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Gibidi2 (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Hybrid (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Tech (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Norton (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Nueva Castilla (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Puertas Lorenzo (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Serviparking (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)
- JCM1G Zibor (KeeLoq, 64 bits) (8bit serial part in Hop - simple learning)

### Alarms, unknown origin, etc.
- APS-1100/APS-2550 (KeeLoq, 64 bits)
- Alligator (KeeLoq, 64 bits)
- Alligator S-275 (KeeLoq, 64 bits)
- Cenmax (KeeLoq, 64 bits)
- Cenmax St-5 (KeeLoq, 64 bits)
- Cenmax St-7 (KeeLoq, 64 bits)
- Faraon (KeeLoq, 64 bits)
- Guard RF-311A (KeeLoq, 64 bits) (normal learning)
- Harpoon (KeeLoq, 64 bits)
- KGB/Subaru (KeeLoq, 64 bits) (magic serial type 1)
- Leopard (KeeLoq, 64 bits)
- Magic 1 (KeeLoq, 64 bits) (magic serial type 2)
- Magic 2 (KeeLoq, 64 bits) (magic serial type 2)
- Magic 3 (KeeLoq, 64 bits) (magic serial type 3)
- Magic 4 (KeeLoq, 64 bits) (magic serial type 3)
- Merlin (KeeLoq, 64 bits) (no serial part in Hop - simple XOR)
- Mongoose (KeeLoq, 64 bits) (normal learning)
- Pantera (KeeLoq, 64 bits)
- Pantera CLK (KeeLoq, 64 bits)
- Pantera XS/Jaguar (KeeLoq, 64 bits)
- Partisan RX (KeeLoq, 64 bits)
- Pecinin (KeeLoq, 64 bits) (12bit serial part in Hop - simple learning)
- Reff (KeeLoq, 64 bits)
- Rossi (KeeLoq, 64 bits) (12bit serial part in Hop - simple learning)
- Rosh (KeeLoq, 64 bits) (12bit serial part in Hop - simple learning)
- Sheriff (KeeLoq, 64 bits)
- SL A2-A4 (KeeLoq, 64 bits)
- SL A6-A9/Tomahawk 9010 (KeeLoq, 64 bits)
- SL B6,B9 dop (KeeLoq, 64 bits)
- Teco (KeeLoq, 64 bits)
- Tomahawk TZ-9030 (KeeLoq, 64 bits)
- Tomahawk Z,X 3-5 (KeeLoq, 64 bits)
- ZX-730-750-1055 (KeeLoq, 64 bits)
- Zero Simple (KeeLoq, 64 bits)
- Zero Normal (KeeLoq, 64 bits)
- FFFF Simple (KeeLoq, 64 bits)
- FFFF Normal (KeeLoq, 64 bits)
- Miserere (KeeLoq, 64 bits) (normal learning)

*Note: Most KeeLoq manufacturers operate in the 433 MHz and 868 MHz frequency bands with AM650 modulation. Some operate at other frequencies or modulations. Not all KeeLoq systems are supported for full decoding or emulation.*

---

## Protocol Type Reference

Unleashed firmware supports various protocol types:

- **Static Code**: Fixed transmission codes (e.g., Roger, Princeton, Marantec, Revers RB2)
- **Rolling Code (Dynamic) (KeeLoq)**: Dynamic codes with rolling counter using KeeLoq encryption (60+ manufacturer systems supported)
- **Rolling Code (Dynamic)**: Other dynamic systems with custom encoding (e.g., CAME Atomo, Nice Flor S, Somfy Telis, FAAC SLH, Alutech AT-4N, Security+)

For more information on how to use some of these protocols, see also [SubGHzRemoteProg.md](/documentation/SubGHzRemoteProg.md) and the main [ReadMe.md](/ReadMe.md).

---

*Docs made for Unleashed FW, please mention source when copying*