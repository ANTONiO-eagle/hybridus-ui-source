from pathlib import Path
import sys,tempfile,subprocess,re,json
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]) if len(sys.argv)>2 else Path.cwd()
src=(root/'applications/services/loader/loader_menu.c').read_text();generated=(root/'build/f7-firmware-C/applications/applications.c').read_text()
def fun(s,sig):
 a=s.index(sig);i=s.index('{',a)+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
arrays={}
for key,typ in [('FLIPPER_APPS','FlipperInternalApplication'),('FLIPPER_EXTERNAL_APPS','FlipperExternalApplication')]:
 a=generated.index(key+'[]');b=generated.index('\n};',a)
 block=generated[a:b]
 rows=[]
 for item in block.split('},'):
  name=re.search(r'\.name = "([^"]+)"',item);icon=re.search(r'\.icon = &(\w+)',item);path=re.search(r'\.path = "([^"]+)"',item)
  if name: rows.append(dict(name=name[1],icon=icon[1],path=path[1] if path else None))
 arrays[key]=rows
icons=set(re.findall(r'&([AI]_\w+)',src))|{x['icon'] for a in arrays.values() for x in a}
code=r'''
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include <assert.h>
#define EXT_PATH(x) "/ext/" x
#define RECORD_STORAGE "storage"
#define RECORD_LOADER "loader"
#define LOADER_APPLICATIONS_NAME "Apps"
#define UNUSED(x) (void)(x)
typedef void FuriThread;typedef void Storage;typedef void File;typedef void Loader;
typedef struct {char* text;} FuriString;
typedef struct {bool dir;} FileInfo;
typedef struct {const uint16_t width,height;const uint8_t frame_count,frame_rate;const uint8_t*const*frames;} Icon;
typedef struct {const char*name;const Icon*icon;const char*path;} FlipperInternalApplication,FlipperExternalApplication;
typedef void(*Cb)(void*,uint32_t);
typedef struct{const char*label;const Icon*icon;Cb callback;void*ctx;uint32_t index;} Entry;
typedef struct{Entry rows[300];size_t count;} Menu;
typedef struct{Entry rows[30];size_t count;char header[300];} Submenu;
typedef struct{int view;} ViewDispatcher;
static int strings,mode,dir_idx;static bool dir_open=true;static char started_name[300],started_args[300];static int starts;
static const uint8_t pix[]={0,1};static const uint8_t*const frames[]={pix};
'''
for name in sorted(icons):
 count=2 if name in ['A_HybridusBluetooth_14','A_HybridusScripts_14'] else 4
 rate=6 if name=='A_HybridusGames_14' else count
 code+=f'static const Icon {name}={{14,14,{count},{rate},frames}};\n'
for key,rows in arrays.items():
 code+=f'static const FlipperInternalApplication {key}[]={{'+','.join('{"'+v['name']+'",&'+v['icon']+','+('"'+v['path']+'"' if v['path'] else 'NULL')+'}' for v in rows)+'};\n'
 code+=f'static const size_t {key}_COUNT=sizeof({key})/sizeof({key}[0]);\n'
code+=fun(src,'struct LoaderMenu {').replace('struct LoaderMenu {','typedef struct {')+' LoaderMenu;\n'
code+='enum{LoaderMenuViewPrimary,LoaderMenuViewSettings,LoaderMenuViewCategory};\n'
code+=r'''
static FuriString*furi_string_alloc_set(const char*s){FuriString*f=malloc(sizeof(*f));f->text=strdup(s);strings++;return f;}
static FuriString*furi_string_alloc_printf(const char*fmt,...){char b[700];va_list a;va_start(a,fmt);vsnprintf(b,sizeof(b),fmt,a);va_end(a);return furi_string_alloc_set(b);}
static const char*furi_string_get_cstr(const FuriString*f){return f->text;}
static int furi_string_cmpi(const FuriString*f,const char*s){return strcasecmp(f->text,s);}
static void furi_string_free(FuriString*f){free(f->text);free(f);strings--;}
static void*furi_record_open(const char*n){return (void*)1;}static void furi_record_close(const char*n){}
static File*storage_file_alloc(Storage*s){return (void*)1;}static void storage_file_free(File*f){}
static bool file_info_is_dir(const FileInfo*i){return i->dir;}
static bool storage_dir_open(File*f,const char*p){dir_idx=0;assert(!strcmp(p,"/ext/apps"));return dir_open;}
static void storage_dir_close(File*f){}
static bool storage_dir_read(File*f,FileInfo*i,char*n,size_t z){
 if(mode==1){if(dir_idx==140)return false;snprintf(n,z,"custom-%03d",dir_idx++);i->dir=true;return true;}
 const char*names[]={"Bluetooth","GPIO","Games","Infrared","Media","NFC","RFID","Scripts","Sub-GHz","Tools","USB","assets","iButton","gpio",".private","a.fap"};
 if(dir_idx==16)return false;snprintf(n,z,"%s",names[dir_idx]);i->dir=dir_idx!=15;dir_idx++;return true;
}
static void loader_start_with_gui_error(Loader*l,const char*n,const char*a){snprintf(started_name,sizeof(started_name),"%s",n);snprintf(started_args,sizeof(started_args),"%s",a?a:"");starts++;}
static void menu_add_item(Menu*m,const char*l,const Icon*i,uint32_t ix,Cb cb,void*ctx){m->rows[m->count++]=(Entry){l,i,cb,ctx,ix};}
static void submenu_reset(Submenu*s){for(size_t i=0;i<s->count;i++)free((void*)s->rows[i].label);s->count=0;}
static void submenu_set_header(Submenu*s,const char*l){snprintf(s->header,sizeof(s->header),"%s",l);}
static void submenu_add_item(Submenu*s,const char*l,uint32_t ix,Cb cb,void*ctx){s->rows[s->count++]=(Entry){strdup(l),NULL,cb,ctx,ix};}
static void submenu_set_selected_item(Submenu*s,uint32_t ix){}
static void view_dispatcher_switch_to_view(ViewDispatcher*d,int i){d->view=i;}
static void loader_menu_switch_to_settings(void*p,uint32_t i){}
'''
code+=(root/'applications/services/loader/loader_categories.h').read_text().replace('#pragma once','')+'\n'
functions=['static void loader_menu_start(','static void loader_menu_apps_callback(', 'static void loader_menu_external_apps_callback(', 'static void loader_menu_applications_callback(',
 'static const char* loader_menu_internal_category(', 'static bool loader_menu_category_contains(', 'static const char* loader_menu_category_label(',
 'static void loader_menu_category_launch_callback(', 'static void loader_menu_category_callback(', 'static size_t loader_menu_find_category(', 'static void loader_menu_add_category(',
 'static const Icon* loader_menu_category_icon(', 'static int loader_menu_category_compare(', 'static void loader_menu_read_categories(', 'static void loader_menu_build_menu(']
for sig in functions:code+=fun(src,sig)+'\n'
code+=r'''
static void setup(LoaderMenu*m){memset(m,0,sizeof(*m));m->primary_menu=calloc(1,sizeof(Menu));m->category_menu=calloc(1,sizeof(Submenu));m->view_dispatcher=calloc(1,sizeof(ViewDispatcher));loader_menu_read_categories(m);m->fallback_icons=malloc(m->category_count*sizeof(Icon));m->fallback_frames=malloc(m->category_count*sizeof(void*));m->fallback_pixels=malloc(m->category_count*29);loader_menu_build_menu(m);}
static void cleanup(LoaderMenu*m){submenu_reset(m->category_menu);free(m->category_menu);free(m->primary_menu);free(m->view_dispatcher);for(size_t i=0;i<m->category_count;i++)furi_string_free(m->categories[i]);free(m->categories);free(m->fallback_icons);free(m->fallback_frames);free(m->fallback_pixels);assert(strings==0);}
static void press(Entry e){e.callback(e.ctx,e.index);}
int main(){
 LoaderMenu m;setup(&m);assert(m.category_count==12);assert(m.primary_menu->count==14);
 puts("SCENARIO official 095E folders + duplicate-case gpio: 12 categories + Apps + Settings = 14 cards, not 24.");
 const char* expected[]={"Apps","Bluetooth","Games","GPIO","iButton","Infrared","Media","NFC","RFID","Scripts","Sub-GHz","Tools","USB","Settings"};
 for(size_t j=0;j<14;++j)assert(!strcmp(m.primary_menu->rows[j].label,expected[j]));
 for(size_t j=2;j<13;++j)assert(strcasecmp(m.primary_menu->rows[j-1].label,m.primary_menu->rows[j].label)<0);
 puts("PASS exact left-to-right category order matches Apps: Bluetooth, Games, GPIO, iButton, Infrared, Media, NFC, RFID, Scripts, Sub-GHz, Tools, USB. Apps first, Settings last.");
 int reached_internal[30]={0},reached_external[30]={0};
 for(size_t i=0;i<m.primary_menu->count;i++){
  Entry e=m.primary_menu->rows[i];
  for(size_t j=0;j<i;j++)assert(strcasecmp(e.label,m.primary_menu->rows[j].label)!=0);
  if(e.callback!=loader_menu_category_callback)continue;
  assert(e.icon&&e.icon!=&A_Plugins_14&&e.icon->frame_rate>0);
  if(!strcasecmp(e.label,"Bluetooth")||!strcasecmp(e.label,"Games")||!strcasecmp(e.label,"Media")||!strcasecmp(e.label,"Scripts"))assert(e.icon->frame_count==((!strcasecmp(e.label,"Scripts")||!strcasecmp(e.label,"Bluetooth"))?2:4)&&e.icon->frame_rate==(!strcasecmp(e.label,"Games")?6:(!strcasecmp(e.label,"Scripts")||!strcasecmp(e.label,"Bluetooth"))?2:4));
  for(size_t j=1;j<i;j++)assert(e.icon!=m.primary_menu->rows[j].icon);
  press(e);const char*path=m.categories[e.index]->text;
  printf("CARD\t%s\t%s",e.label,path);
  if(m.category_menu->count){
   for(size_t k=0;k<m.category_menu->count;k++){
    Entry c=m.category_menu->rows[k];printf("\t%s",c.label);int prior=starts;press(c);assert(starts==prior+1);
    if(c.index<FLIPPER_APPS_COUNT){assert(!strcmp(started_name,FLIPPER_APPS[c.index].name));assert(!*started_args);reached_internal[c.index]++;}
    else if(c.index-FLIPPER_APPS_COUNT<FLIPPER_EXTERNAL_APPS_COUNT){int ix=c.index-FLIPPER_APPS_COUNT;assert(!strcmp(started_name,FLIPPER_EXTERNAL_APPS[ix].name));assert(!*started_args);reached_external[ix]++;}
    else {assert(!strcmp(started_name,"Apps"));assert(!strcmp(started_args,path));}
   }
  }else{assert(!strcmp(started_name,"Apps"));assert(!strcmp(started_args,path));printf("\t[direct browser]");}
  puts("");submenu_reset(m.category_menu);
 }
 for(size_t i=0;i<FLIPPER_APPS_COUNT;i++)assert(reached_internal[i]==1);
 for(size_t i=0;i<FLIPPER_EXTERNAL_APPS_COUNT;i++)assert(reached_external[i]==1);
 press(m.primary_menu->rows[0]);assert(!strcmp(started_name,"Apps")&&!*started_args);
 assert(!loader_menu_category_contains("/ext/apps/NFC","/ext/apps/NFC2/nfc.fap"));
 assert(!loader_menu_category_contains("/ext/apps/NFC","/ext/apps/NFC/nested/nfc.fap"));
 cleanup(&m);
 dir_open=false;setup(&m);assert(m.category_count==8);assert(m.primary_menu->count==10);cleanup(&m);dir_open=true;
 mode=1;setup(&m);assert(m.category_count==136);assert(m.primary_menu->count==138);
 for(size_t i=0;i<m.category_count;i++){const Icon*icon=loader_menu_category_icon(&m,i);assert(icon&&icon->frame_rate>0);}
 for(size_t i=0;i<128;i++)for(size_t j=0;j<i;j++){
   // custom folders have distinct pixels, no shared Apps folder emblem.
   assert(memcmp(m.fallback_pixels+29*i,m.fallback_pixels+29*j,29)!=0);
 }
 cleanup(&m);
 puts("PASS actual C scanner/grouping/menu/callback/icon branches: all 10 original instruments reachable exactly once; 14 unique cards; matching by directory; no duplicate GPIO/RFID/Sub-GHz/USB/Tools; case-fold dedup; alphabetical order and Tools with Clock inside; missing-SD preserves tools; 128 custom categories; unique icons/lifetimes; Apps unchanged; no leaked strings.");
}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'test.c';p.write_text(code);exe=p.with_suffix('');subprocess.run([sys.executable,'-m','ziglang','cc','-std=gnu11','-g','-fsanitize=undefined',str(p),'-o',str(exe)],check=True)
 result=subprocess.run([str(exe)],capture_output=True,text=True);print(result.stdout);print(result.stderr,end='',file=sys.stderr);result.check_returncode()
 for line in result.stdout.splitlines():
  if line.startswith('CARD\t'):pass
 for forbidden in ['storage_file_write','storage_common_copy','storage_common_remove','storage_common_rename','storage_common_mkdir']:
  assert forbidden not in src,forbidden
 # No public API, file-browser lifecycle, apps, radio or color backend changes vs 0.3.
 assert 'LoaderMenuViewCategory, category_view' in src
 assert 'view_set_previous_callback(category_view, loader_menu_switch_to_primary)' in src
 assert 'menu_free(loader_menu->primary_menu);' in src
 assert src.index('menu_free(loader_menu->primary_menu);') < src.index('free(loader_menu->fallback_icons);')
 assert 'submenu_free(loader_menu->category_menu);' in src
 print('PASS static integration: category Back returns primary, frees after menu timers/icons, no SD write/copy/move/delete APIs.')
