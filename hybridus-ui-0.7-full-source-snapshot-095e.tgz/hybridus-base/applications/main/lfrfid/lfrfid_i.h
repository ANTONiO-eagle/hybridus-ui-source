#pragma once

#include <furi.h>
#include <furi_hal.h>

#include <gui/gui.h>
#include <gui/view.h>
#include <assets_icons.h>
#include <gui/view_dispatcher.h>
#include <gui/scene_manager.h>
#include <notification/notification_messages.h>

#include <gui/modules/submenu.h>
#include <gui/modules/dialog_ex.h>
#include <gui/modules/popup.h>
#include <gui/modules/text_input.h>
#include <gui/modules/byte_input.h>
#include <gui/modules/number_input.h>
#include <gui/modules/widget.h>
#include <gui/modules/variable_item_list.h>

#include <lfrfid/views/lfrfid_view_read.h>

#include <notification/notification_messages.h>
#include <dialogs/dialogs.h>
#include <storage/storage.h>
#include <flipper_format/flipper_format.h>

#include <rpc/rpc_app.h>

#include <toolbox/protocols/protocol_dict.h>
#include <toolbox/path.h>
#include <lfrfid/lfrfid_dict_file.h>
#include <lfrfid/tools/t5577_file.h>
#include <lfrfid/lfrfid_settings.h>
#include <lfrfid/lfrfid_write_targets.h>
#include <lfrfid/protocols/lfrfid_protocols.h>
#include <lfrfid/lfrfid_worker.h>

#include <lfrfid/scenes/lfrfid_scene.h>
#include "helpers/lfrfid_manual_format.h"

#define LFRFID_KEY_NAME_SIZE   22
#define LFRFID_TEXT_STORE_SIZE 40

#define LFRFID_APP_FOLDER                    EXT_PATH("lfrfid")
#define LFRFID_SD_FOLDER                     EXT_PATH("lfrfid")
#define LFRFID_APP_FILENAME_PREFIX           "RFID"
#define LFRFID_APP_FILENAME_EXTENSION        ".rfid"
#define LFRFID_APP_SHADOW_FILENAME_EXTENSION ".shd"

#define LFRFID_APP_RAW_ASK_EXTENSION    ".ask.raw"
#define LFRFID_APP_RAW_PSK_EXTENSION    ".psk.raw"
#define LFRFID_APP_RAW_ASK134_EXTENSION ".ask134.raw"

enum LfRfidCustomEvent {
    LfRfidEventNext = 100,
    LfRfidEventExit,
    LfRfidEventPopupClosed,
    LfRfidEventReadSenseStart,
    LfRfidEventReadSenseEnd,
    LfRfidEventReadSenseCardStart,
    LfRfidEventReadSenseCardEnd,
    LfRfidEventReadStartASK,
    LfRfidEventReadStartPSK,
    LfRfidEventReadStartASK134,
    LfRfidEventReadDone,
    LfRfidEventReadOverrun,
    LfRfidEventReadError,
    LfRfidEventWriteOK,
    LfRfidEventWriteProtocolCannotBeWritten,
    LfRfidEventWriteNoEnabledTarget,
    LfRfidEventWriteFobCannotBeWritten,
    LfRfidEventWriteTooLongToWrite,
    LfRfidEventWriteCannotRead,
    LfRfidEventWriteAlreadyProtected,
    LfRfidEventWriteKeyNotStored,
    LfRfidEventWritePasswordNotStored,
    LfRfidEventWriteProtectionRefused,
    LfRfidEventWriteProtectionUnchecked,
    LfRfidEventWriteProgress,
    LfRfidEventRpcLoadFile,
    LfRfidEventRpcSessionClose,
};

typedef enum {
    LfRfidRpcStateIdle,
    LfRfidRpcStateEmulating,
} LfRfidRpcState;

typedef struct LfRfid LfRfid;

struct LfRfid {
    LFRFIDWorker* lfworker;
    ViewDispatcher* view_dispatcher;
    Gui* gui;
    NotificationApp* notifications;
    SceneManager* scene_manager;
    Storage* storage;
    DialogsApp* dialogs;
    Widget* widget;

    char text_store[LFRFID_TEXT_STORE_SIZE + 1];
    FuriString* file_path;
    FuriString* file_name;
    FuriString* raw_file_name;

    ProtocolDict* dict;
    ProtocolId protocol_id;
    ProtocolId protocol_id_next;
    LFRFIDWorkerReadType read_type;

    uint8_t* old_key_data;
    uint8_t* new_key_data;

    uint32_t manual_format; // Add Manually entry, see lfrfid_manual_format.h
    uint64_t field_values[LFRFID_MANUAL_FORMAT_FIELDS_MAX]; // its fields entered so far
    size_t field_index; // the field being entered

    uint8_t password[4];

    RpcAppSystem* rpc_ctx;
    LfRfidRpcState rpc_state;

    // Common Views
    Submenu* submenu;
    DialogEx* dialog_ex;
    Popup* popup;
    TextInput* text_input;
    ByteInput* byte_input;
    NumberInput* number_input;
    VariableItemList* variable_item_list; // allocated on first use, see the settings scene

    // Custom views
    LfRfidReadView* read_view;
};

typedef enum {
    LfRfidViewSubmenu,
    LfRfidViewDialogEx,
    LfRfidViewPopup,
    LfRfidViewWidget,
    LfRfidViewTextInput,
    LfRfidViewByteInput,
    LfRfidViewNumberInput,
    LfRfidViewVariableItemList,
    LfRfidViewRead,
} LfRfidView;

typedef enum {
    LfRfidMenuIndexRead,
    LfRfidMenuIndexSaved,
    LfRfidMenuIndexAddManually,
    LfRfidMenuIndexExtraActions,
    LfRfidMenuIndexSettings,
} LfRfidMenuIndex;

bool lfrfid_save_key(LfRfid* app);

/** Show the saved list. True when a file was picked, with its path in app->file_path. */
bool lfrfid_select_key_file(LfRfid* app);

/** Hand the dump in app->file_path to the app that reads T5577 dumps.
 *
 * On success this app is stopped: the loader runs the other app, and then launches this one
 * again on the saved list when it can find its own launch path. False means nothing was handed
 * over and the caller is still running, with the reason already on screen.
 */
bool lfrfid_run_t5577_app(LfRfid* app);

bool lfrfid_load_raw_key_from_file_select(LfRfid* app);

bool lfrfid_delete_key(LfRfid* app);

bool lfrfid_delete_key_file(LfRfid* app, const FuriString* path);

bool lfrfid_load_key_data(LfRfid* app, FuriString* path, bool show_dialog);

bool lfrfid_save_key_data(LfRfid* app, FuriString* path);

void lfrfid_make_app_folder(LfRfid* app);

void lfrfid_text_store_set(LfRfid* app, const char* text, ...);

void lfrfid_text_store_clear(LfRfid* app);

void lfrfid_popup_timeout_callback(void* context);

void lfrfid_widget_callback(GuiButtonType result, InputType type, void* context);

void lfrfid_text_input_callback(void* context);
