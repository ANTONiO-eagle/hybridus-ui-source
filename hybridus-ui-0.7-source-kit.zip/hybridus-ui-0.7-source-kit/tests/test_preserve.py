"""Execute real preserve predicate, flash worker and post-update C bodies with I/O spies."""
from pathlib import Path
import subprocess,sys,tempfile,re
root=Path(sys.argv[1]);u=root/'applications/system/updater/util'
def function(text,signature):
 start=text.index(signature);b=text.index('{',start);level=1;i=b+1
 while level:
  if text[i]=='{':level+=1
  elif text[i]=='}':level-=1
  i+=1
 return text[start:i]
header=(u/'hybridus_preserve.h').read_text()
predicate=function(header,'static inline bool hybridus_preserve_package(')+'\n'+function(header,'static inline bool hybridus_preserve_manifest_allowed(')+'\nstatic bool update_task_parse_manifest(UpdateTask*t){return parse_ok && hybridus_preserve_manifest_allowed(t);}'
flash=function((u/'update_task_worker_flasher.c').read_text(),'int32_t update_task_worker_flash_writer(')
post=function((u/'update_task_worker_backup.c').read_text(),'static bool update_task_post_update(')
stub=r'''
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#define HYBRIDUS_PRESERVE_INFO "hybridus-ui-0.7-095e-preserve"
#define furi_assert assert
#define CHECK_RESULT(x) if(!(x)){break;}
#define UPDATE_TASK_NOERR 0
#define UPDATE_TASK_FAILED -1
#define INT_BACKUP_DEFAULT_FILENAME "backup.tar"
#define SLIDESHOW_FILE_NAME ".slideshow"
#define STORAGE_EXT_PATH_PREFIX "/ext"
#define INT_PATH(x) "/int/" x
#define FSE_OK 0
#define FURI_NDEBUG 1
#define NULLSTR ""
typedef char FuriString;typedef int TarArchive;
typedef struct {unsigned target;const char*version,*firmware_dfu_image,*radio_image,*resource_bundle,*splash_file;bool ob;} UpdateManifest;
typedef struct {unsigned groups;} State;
typedef struct {UpdateManifest*manifest;State state;void*storage;const char*update_path;} UpdateTask;
typedef struct {UpdateTask*update_task;TarArchive*archive;} TarUnpackProgress;
enum {UpdateTaskStageGroupRadio=1,UpdateTaskStageGroupOptionBytes=2,UpdateTaskStageGroupFirmware=4,UpdateTaskStageGroupResources=8,UpdateTaskStageGroupSplashscreen=16};
enum {FuriHalRtcBootModePostUpdate, FuriHalRtcFlagStorageFormatInternal, FuriLogLevelNone, FuriHalRtcFlagDebug, FuriHalRtcFlagLegacySleep, FuriHalRtcHeapTrackModeNone,UpdateTaskStageCompleted,UpdateTaskStageError,UpdateTaskStageIntRestore,UpdateTaskStageResourcesFileUnpack,UpdateTaskStageSplashscreenInstall,TarOpenModeReadHeatshrink};
static int format_set,format_clear,flash_calls,restore_calls,resource_cleanup,resource_unpack,splash_copy,allocs,radio_calls,ob_calls,boot_calls;
static bool parse_ok=true,flash_ok=true;static char dummy[64];static int archive;
static bool furi_string_equal(const char*a,const char*b){return strcmp(a,b)==0;}
static bool furi_string_empty(const char*a){return !a[0];}
static bool update_manifest_has_obdata(UpdateManifest*m){return m->ob;}
static bool update_task_parse_manifest(UpdateTask*t);
static bool update_task_manage_radiostack(UpdateTask*t){radio_calls++;return true;}
static bool update_task_validate_optionbytes(UpdateTask*t){ob_calls++;return true;}
static bool update_task_write_dfu(UpdateTask*t){flash_calls++;return flash_ok;}
static void furi_hal_rtc_set_boot_mode(int b){boot_calls++;}
static void furi_hal_rtc_set_flag(int f){if(f==FuriHalRtcFlagStorageFormatInternal)format_set++;}
static void furi_hal_rtc_reset_flag(int f){if(f==FuriHalRtcFlagStorageFormatInternal)format_clear++;}
static void furi_hal_rtc_set_log_level(int v){}
static void furi_hal_rtc_set_heap_track_mode(int v){}
static void update_task_set_progress(UpdateTask*t,int stage,int pct){}
static FuriString* furi_string_alloc(void){allocs++;return dummy;}
static FuriString* furi_string_alloc_set(const char*s){allocs++;return dummy;}
static void furi_string_free(FuriString*s){}
static const char* furi_string_get_cstr(const char*s){return s;}
static void path_concat(const char*a,const char*b,FuriString*c){}
static void path_append(FuriString*a,const char*b){}
static TarArchive*tar_archive_alloc(void*s){allocs++;return &archive;}
static void tar_archive_free(TarArchive*t){}
static bool int_backup_unpack(void*s,const char*p){restore_calls++;return true;}
static bool tar_archive_open(TarArchive*t,const char*p,int mode){return true;}
static void update_task_cleanup_resources(UpdateTask*t){resource_cleanup++;}
static bool update_task_resource_unpack_cb(const char*n,bool d,void*c){return true;}
static void tar_archive_set_file_callback(TarArchive*t,void*cb,void*c){}
static bool tar_archive_unpack_to(TarArchive*t,const char*p,void*c){resource_unpack++;return true;}
static int storage_common_copy(void*s,const char*a,const char*b){splash_copy++;return FSE_OK;}
static void reset(void){format_set=format_clear=flash_calls=restore_calls=resource_cleanup=resource_unpack=splash_copy=allocs=radio_calls=ob_calls=boot_calls=0;parse_ok=flash_ok=true;}
'''
tests=r'''
int main(void){
 UpdateManifest m={7,HYBRIDUS_PRESERVE_INFO,"firmware.dfu","","","",false};UpdateTask t={&m,{UpdateTaskStageGroupFirmware},NULL,"/ext/update/test"};
 assert(hybridus_preserve_package(&t));
 assert(update_task_worker_flash_writer(&t)==0);
 assert(flash_calls==1&&format_set==0&&format_clear==1&&radio_calls==0&&ob_calls==0);
 reset();assert(update_task_post_update(&t));
 assert(!restore_calls&&!resource_cleanup&&!resource_unpack&&!splash_copy&&!allocs);
 // Nonmatching targets/Info, any destructive extra component, empty firmware: no bypass.
 m.target=6;assert(!hybridus_preserve_package(&t));m.target=7;
 m.version="unlshd-096e";assert(!hybridus_preserve_package(&t));m.version=HYBRIDUS_PRESERVE_INFO;
 m.firmware_dfu_image="";assert(!hybridus_preserve_package(&t));m.firmware_dfu_image="firmware.dfu";
 m.radio_image="radio.bin";assert(!hybridus_preserve_package(&t));assert(!hybridus_preserve_manifest_allowed(&t));reset();assert(update_task_worker_flash_writer(&t)==-1);assert(!flash_calls&&!format_set&&!boot_calls);m.radio_image="";
 m.resource_bundle="resources.ths";assert(!hybridus_preserve_package(&t));assert(!hybridus_preserve_manifest_allowed(&t));m.resource_bundle="";
 m.splash_file="splash.bin";assert(!hybridus_preserve_package(&t));m.splash_file="";
 m.ob=true;assert(!hybridus_preserve_package(&t));m.ob=false;
 // Existing standard updater policy is retained for a future standard release.
 m.version="unlshd-096e";reset();assert(update_task_worker_flash_writer(&t)==0);assert(format_set==1&&!format_clear);
 reset();t.state.groups=UpdateTaskStageGroupFirmware|UpdateTaskStageGroupResources|UpdateTaskStageGroupSplashscreen;
 assert(update_task_post_update(&t));assert(restore_calls==1&&resource_cleanup==1&&resource_unpack==1&&splash_copy==1);
 // Flash failure must not request post-update or format/clear anything.
 m.version=HYBRIDUS_PRESERVE_INFO;t.state.groups=UpdateTaskStageGroupFirmware;reset();flash_ok=false;
 assert(update_task_worker_flash_writer(&t)==-1);assert(!format_set&&!format_clear&&!boot_calls);
 reset();parse_ok=false;assert(update_task_worker_flash_writer(&t)==-1);assert(!flash_calls&&!boot_calls);
 puts("PASS preserve: exact opt-in, no int restore/SD cleanup/extract/splash; no format flag; other releases keep stock policy; failure paths stop");
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'preserve.c';p.write_text(stub+predicate+'\n'+flash+'\n'+post+'\n'+tests);exe=p.with_suffix('')
 subprocess.run([sys.executable,'-m','ziglang','cc','-std=gnu11','-O0','-Wno-unused-function',str(p),'-o',str(exe)],check=True)
 subprocess.run([str(exe)],check=True)
print('I/O spies are host tests, not a hardware update simulation.')
