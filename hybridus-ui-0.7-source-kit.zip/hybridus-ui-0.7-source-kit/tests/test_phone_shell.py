from pathlib import Path
import sys,subprocess,tempfile
root=Path(sys.argv[1]).resolve();s=(root/'applications/settings/phone_shell/phone_shell.c').read_text();s='\n'.join(l for l in s.splitlines() if not l.startswith('#include'))
code=r'''
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#define UNUSED(x) (void)(x)
#define VIEW_NONE 99
#define RECORD_GUI "gui"
#define ViewDispatcherTypeFullscreen 1
typedef void Gui;typedef void View;typedef void ViewDispatcher;
typedef struct{uint8_t index;char text[40];void(*callback)(void*);} VariableItem;
typedef struct{VariableItem item;int count;} VariableItemList;
static VariableItemList list;static uint8_t saved=1;static bool fail;static int runs;
static uint8_t hybridus_color_get(void){return saved;}
static bool hybridus_color_set(uint8_t v){if(fail)return false;assert(v<4);saved=v;return true;}
static uint8_t variable_item_get_current_value_index(VariableItem*i){return i->index;}
static void variable_item_set_current_value_index(VariableItem*i,uint8_t v){i->index=v;}
static void variable_item_set_current_value_text(VariableItem*i,const char*v){snprintf(i->text,sizeof(i->text),"%s",v);}
static void*furi_record_open(const char*n){return (void*)1;}static void furi_record_close(const char*n){}
static VariableItemList*variable_item_list_alloc(void){memset(&list,0,sizeof(list));return &list;}
static VariableItem*variable_item_list_add(VariableItemList*l,const char*n,uint8_t count,void(*cb)(VariableItem*),void*ctx){assert(!strcmp(n,"Color"));assert(count==4&&cb);l->count++;return &l->item;}
static View*variable_item_list_get_view(VariableItemList*l){return (void*)1;}
static void view_set_previous_callback(View*v,uint32_t(*cb)(void*)) {assert(cb(NULL)==VIEW_NONE);}
static ViewDispatcher*view_dispatcher_alloc(void){return (void*)1;}
#define view_dispatcher_attach_to_gui(...) ((void)0)
#define view_dispatcher_add_view(...) ((void)0)
#define view_dispatcher_switch_to_view(...) ((void)0)
#define view_dispatcher_remove_view(...) ((void)0)
#define view_dispatcher_free(...) ((void)0)
#define variable_item_list_free(...) ((void)0)
static void view_dispatcher_run(ViewDispatcher*d){assert(list.count==1);assert(list.item.index==saved);assert(!strcmp(list.item.text,"Black"));runs++;}
'''+s+r'''
int main(){assert(phone_shell_app(NULL)==0&&runs==1);VariableItem i={0};for(int v=0;v<4;v++){i.index=v;phone_shell_changed(&i);assert(saved==v);assert(!strcmp(i.text,color_names[v]));}saved=1;fail=true;i.index=3;phone_shell_changed(&i);assert(saved==1&&i.index==1);assert(!strcmp(i.text,"Save failed"));puts("PASS actual Phone Shell app/init/callback: exactly one Color row, four choices, saved state loaded, all selections saved, save failure rolls back; no Reported/Reboot rows.");}
'''
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'test.c';p.write_text(code);e=p.with_suffix('');subprocess.run([sys.executable,'-m','ziglang','cc','-std=gnu11',str(p),'-o',str(e)],check=True);subprocess.run([str(e)],check=True)
