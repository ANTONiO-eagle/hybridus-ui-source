from pathlib import Path
import sys,re,subprocess,tempfile
from PIL import Image
r=Path(sys.argv[1]).resolve();icons=(r/'build/f7-firmware-C/assets/compiled/assets_icons.c').read_text()
code='''#include <stdint.h>\n#include <stdbool.h>\n#include <string.h>\n#include <assert.h>\n#include <stdio.h>\ntypedef struct {const uint16_t width,height;const uint8_t frame_count,frame_rate;const uint8_t*const*frames;} Icon;\ntypedef struct {const Icon*icon;uint8_t frame;bool animating;}IconAnimation;\n#define furi_assert assert\n#define furi_check assert\n'''
def fun(s,sig):
 a=s.index(sig);i=s.index('{',a)+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
for name in ['Bluetooth','Games','Media','Scripts']:
 key='A_Hybridus'+name+'_14';folder=r/'assets/icons/MainMenu'/('Hybridus'+name+'_14')
 fs=sorted(folder.glob('frame_*.png'));assert len(fs)==(4 if name=='Games' else 2 if name in ['Scripts','Bluetooth'] else 4)
 ims=[Image.open(p) for p in fs];assert all(im.size==(14,14) and im.mode=='1' for im in ims)
 assert len({im.tobytes() for im in ims})>=2,name
 assert (folder/'frame_rate').read_text().strip()==('6' if name=='Games' else '2' if name in ['Scripts','Bluetooth'] else '4')
 # Compile actual generated packed frames, frame pointers and Icon descriptor.
 lines=[l for l in icons.splitlines() if key in l]
 assert len(lines)==(6 if name=='Games' else 4 if name in ['Scripts','Bluetooth'] else 6),(key,len(lines));code+='\n'.join(lines)+'\n'
 assert 'frame_count='+str(len(fs)) in lines[-1] and 'frame_rate='+('6' if name=='Games' else '2' if name in ['Scripts','Bluetooth'] else '4') in lines[-1]
code+=fun((r/'applications/services/gui/icon_animation.c').read_text(),'void icon_animation_next_frame(')+'\n'
code+=fun((r/'applications/services/gui/icon_animation.c').read_text(),'bool icon_animation_is_last_frame(')+'\n'
code+='int main(){const Icon*icons[]={&A_HybridusBluetooth_14,&A_HybridusGames_14,&A_HybridusMedia_14,&A_HybridusScripts_14};for(int k=0;k<4;k++){IconAnimation a={.icon=icons[k]};for(int i=0;i<20;i++){assert(a.frame==i%a.icon->frame_count);assert(icon_animation_is_last_frame(&a)==(i%a.icon->frame_count==a.icon->frame_count-1));assert(a.icon->frames[a.frame]);icon_animation_next_frame(&a);}assert(a.frame==0);}puts("PASS four production compiled 14x14 icons: Media 4 frames/4 fps, Games 4 frames/6 fps, Bluetooth/Scripts 2 frames/2 fps, >=2 distinct PNG states each; real IconAnimation loops 20 steps and wraps safely.");}\n'
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'test.c';p.write_text(code);e=p.with_suffix('');subprocess.run([sys.executable,'-m','ziglang','cc','-std=gnu11',str(p),'-o',str(e)],check=True);subprocess.run([str(e)],check=True)
