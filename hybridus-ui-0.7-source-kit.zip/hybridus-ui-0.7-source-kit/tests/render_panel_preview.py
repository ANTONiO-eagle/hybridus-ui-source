from pathlib import Path
import subprocess,sys,re
r=Path(sys.argv[1]).resolve();o=Path(sys.argv[2]).resolve();o.mkdir(parents=True,exist_ok=True)
def fun(s,sig):
 a=s.index(sig);i=s.index('{',a)+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
v=(r/'applications/services/desktop/views/desktop_view_quick_settings.c').read_text();h=(r/'applications/services/desktop/views/desktop_view_quick_settings.h').read_text();e=(r/'applications/services/gui/elements.c').read_text();font=(r/'lib/u8g2/u8g2_fonts.c').read_text(encoding='latin1');a=font.index('const uint8_t u8g2_font_haxrcorp4089_tr[');b=font.index(';\n',a)+1
stub='''#include "u8g2.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#define furi_check assert
#define HYBRIDUS_SLIDER_TOP 18
#define HYBRIDUS_SLIDER_HEIGHT 43
#define HYBRIDUS_SLIDER_WIDTH 14
#define STATUS_BAR_Y_SHIFT 13
typedef struct {u8g2_t fb;uint8_t data[1024];} Canvas;
typedef struct {int w,h;uint8_t data[550];} Icon;
enum {ColorWhite=0,ColorBlack=1,ColorXOR=2,FontSecondary=9,AlignCenter=10};
static void canvas_set_color(Canvas*c,int a){u8g2_SetDrawColor(&c->fb,a);}
static void canvas_set_font(Canvas*c,int a){u8g2_SetFontMode(&c->fb,1);u8g2_SetFont(&c->fb,u8g2_font_haxrcorp4089_tr);}
static void canvas_draw_box(Canvas*c,int x,int y,int w,int h){u8g2_DrawBox(&c->fb,x,y,w,h);}
static void canvas_draw_rbox(Canvas*c,int x,int y,int w,int h,int rad){u8g2_DrawRBox(&c->fb,x,y,w,h,rad);}
static void canvas_draw_rframe(Canvas*c,int x,int y,int w,int h,int rad){u8g2_DrawRFrame(&c->fb,x,y,w,h,rad);}
static void canvas_draw_line(Canvas*c,int x,int y,int a,int b){u8g2_DrawLine(&c->fb,x,y,a,b);}
static void canvas_draw_dot(Canvas*c,int x,int y){u8g2_DrawPixel(&c->fb,x,y);}
static void canvas_draw_str_aligned(Canvas*c,int x,int y,int h,int v,const char*s){x-=u8g2_GetUTF8Width(&c->fb,s)/2;y+=u8g2_GetAscent(&c->fb)/2;u8g2_DrawUTF8(&c->fb,x,y,s);}
static int icon_get_width(const Icon*i){return i->w;}
static int icon_get_height(const Icon*i){return i->h;}
static void canvas_draw_icon(Canvas*c,int x,int y,const Icon*i){u8g2_DrawXBM(&c->fb,x,y,i->w,i->h,i->data);}
'''
# Convert stock 1-bit PNG pixels exactly to uncompressed XBM for this host canvas.
from PIL import Image
for name in ['I_Pin_star_7x7','I_Volup_8x6','I_DoorLeft_70x55','I_DoorRight_70x55']:
 path=next((r/'assets/icons').rglob(name[2:]+'.png'))
 im=Image.open(path).convert('1');data=[]
 for y in range(im.height):
  for bx in range((im.width+7)//8):data.append(sum(1<<bit for bit in range(8) if bx*8+bit<im.width and im.getpixel((bx*8+bit,y))==0))
 stub+='static Icon '+name+'={'+str(im.width)+','+str(im.height)+',{'+','.join(map(str,data))+'}};\n'
# Do not hard-code control geometry in the renderer; use production macros.
stub=re.sub(r'#define HYBRIDUS_SLIDER_WIDTH \d+',re.search(r'#define HYBRIDUS_SLIDER_WIDTH \d+',v)[0],stub)
body=stub+font[a:b]+'\n'+fun(h,'typedef struct {')+' DesktopQuickSettingsViewModel;\n'+fun(e,'void elements_frame(')+'\n'+fun(e,'void elements_bold_rounded_frame(')+'\n'+fun(v,'static void desktop_quick_settings_button(')+'\n'+fun(v,'static void desktop_quick_settings_draw_callback(')
body=body.replace('    if(on) {','    int tw=u8g2_GetUTF8Width(&canvas->fb,label); if(!strcmp(label,"BT")||!strcmp(label,"Dummy"))assert(tw <= w-4); printf(\"label=%s text=%d cell=%d padding=%d\\n\",label,tw,w,w-tw);\n    if(on) {')
body+='''
int main(void){
 static const u8x8_display_info_t info={.tile_width=16,.tile_height=8,.pixel_width=128,.pixel_height=64};
 for(int idx=0;idx<28;idx++){
  Canvas c={0};c.fb.u8x8.display_info=&info;
  u8g2_SetupBuffer(&c.fb,c.data,8,u8g2_ll_hvline_vertical_top_lsb,U8G2_R0);
  DesktopQuickSettingsViewModel m={.idx=idx%7,.brightness=idx/7==1?0:(idx/7==2?20:13),.volume=idx/7==1?0:(idx/7==2?20:8),.bluetooth=true,.vibro=true,.left_hand=idx/7==3};
  if(idx/7==3)u8g2_SetDisplayRotation(&c.fb,U8G2_R2);
  desktop_quick_settings_draw_callback(&c,&m);
  char path[700];snprintf(path,sizeof(path),"OUT/frame-%d.pbm",idx);
  FILE*f=fopen(path,"wb");fprintf(f,"P1\\n128 64\\n");
  for(int y=0;y<64;y++){for(int x=0;x<128;x++)fprintf(f,"%d ",(c.data[x+(y/8)*128]>>(y%8))&1);fprintf(f,"\\n");}fclose(f);
 }
 puts("PASS seven focus states rendered with production draw functions, real u8g2/font/assets; not hardware.");
}
'''
body=body.replace('OUT/',str(o)+'/')
(o/'render.c').write_text(body)
files=[str(x) for x in (r/'lib/u8g2').glob('*.c') if x.name not in ['u8g2_fonts.c','u8g2_glue.c']]
subprocess.run([sys.executable,'-m','ziglang','cc','-std=gnu11','-Os','-UNDEBUG','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I'+str(r/'lib/u8g2'),str(o/'render.c'),*files,'-o',str(o/'render')],check=True)
subprocess.run([str(o/'render')],check=True)
from PIL import Image,ImageDraw
im=Image.new('RGB',(768,4*218+35),'#e5e5e5');d=ImageDraw.Draw(im)
d.text((8,8),'Quick Settings 0.7 - HOST PREVIEW / NOT DEVICE',fill='black')
for j,i in enumerate([0,2,3,4,5,6,14,21]):
 src=Image.open(o/f'frame-{i}.pbm').convert('RGB').resize((384,192),Image.Resampling.NEAREST)
 x=(j%2)*384;y=(j//2)*218+35;im.paste(src,(x,y+17));d.text((x+3,y),['Light','Bluetooth','Dummy','Vibration','Mute','Hand','100 percent','Left hand'][j],fill='black')
im.save(o/'quick-settings-07.png')
