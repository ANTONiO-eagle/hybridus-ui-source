from pathlib import Path
from PIL import Image
import sys
r=Path(sys.argv[1]).resolve();o=Path(sys.argv[2]).resolve()
# Proof against rendered pixels, not a stub rectangle: the bold-frame helper
# includes x+width, unlike an ordinary canvas rframe.
for i in [0,1,7,8,14,15,21,22]:
 im=Image.open(o/f'frame-{i}.pbm').convert('1');cols=[33,34] if i%7==0 else [32,33]
 for x in cols:
  for y in range(17,63):
   p=(127-x,63-y) if i>=21 else (x,y)
   assert im.getpixel(p)!=0,(i,p,'slider focus gap is not white')
# Original file-browser icon background (silhouette enlarged by nearest neighbour).
a=r/'assets/icons';ref=Image.open(a/'Archive/js_script_10px.png').convert('1');bg=Image.new('1',(10,10),1)
from PIL import ImageDraw
for y in range(10):
 xs=[x for x in range(10) if ref.getpixel((x,y))==0]
 if xs:ImageDraw.Draw(bg).line((min(xs),y,max(xs),y),fill=0)
bg=bg.resize((14,14),Image.Resampling.NEAREST)
j=['01111','00010','00010','00010','00010','10010','01100'];s=['01111','10000','10000','01110','00001','00001','11110']
for i,dy in enumerate([3,4],1):
 mask={(ox+x,dy+y) for ox,g in [(1,j),(8,s)] for y,row in enumerate(g) for x,c in enumerate(row) if c=='1'}
 im=Image.open(a/'MainMenu/HybridusScripts_14'/f'frame_{i:02d}.png').convert('1')
 for y in range(14):
  for x in range(14):assert (im.getpixel((x,y))!=0)==((x,y) in mask or bg.getpixel((x,y))!=0)
print('PASS real rendered pixel gap: 2 full white columns between focused slider and adjacent slider, 0/65/100% and left-hand rotation. Scripts: exact animated white JS mask on silhouette of stock Archive/js_script_10px.png, both frames.')
